particlesJS.load('particles-js', 'assets/particles.json',
    function () {
        // console.log('particles.json loaded...')
    })