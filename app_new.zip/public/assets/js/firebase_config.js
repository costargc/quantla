// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: atob("QUl6YVN5QXhFVnMzQVVVLTNWVmhWX0tQdmVkSmw0U2pDdC1XVkFJ"),
  authDomain: atob("cXVhbnRsYS5maXJlYmFzZWFwcC5jb20="),
  databaseURL: atob("aHR0cHM6Ly9xdWFudGxhLmZpcmViYXNlaW8uY29t"),
  projectId: "quantla",
  storageBucket: atob("cXVhbnRsYS5hcHBzcG90LmNvbQ=="),
  messagingSenderId: atob("NzAyNjA0ODczMTU5"),
  appId: atob("MTo3MDI2MDQ4NzMxNTk6d2ViOmI3MzgwNzgyNTZjNzYxYjU=")
};
